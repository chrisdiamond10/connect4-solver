# Connect 4 Game Solver

This C++ source code is published under AGPL v3 license.

It illustrates how to write a strong Connect AI, following the [step by step tutorial to solve connect 4](http://blog.gamesolver.org)


